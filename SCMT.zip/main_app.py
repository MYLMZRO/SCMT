import sys
import requests
import time
from datetime import datetime, timedelta
import os
import json
import webbrowser
import subprocess
import simpleaudio as sa
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QStatusBar,
    QGridLayout,
    QTableWidget,
    QTableWidgetItem,
    QAbstractItemView,
    QHeaderView,
    QGroupBox,
    QFormLayout,
    QLineEdit,
    QPushButton,
    QDialog,
    QMessageBox,
    QDialogButtonBox,
    QAction,
    QMenu,
    QTabWidget,
    QSpinBox,
    QComboBox,
    QSplitter,
)
from PyQt5.QtCore import QTimer, Qt, QSettings, QUrl
from PyQt5.QtGui import QIcon, QColor
from PyQt5.QtMultimedia import QSoundEffect

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import matplotlib.dates as mdates

import db_manager


def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


LIGHT_THEME_QSS = """ /* Basic Light Theme or empty to use system default */ """
DARK_THEME_QSS = """
    QWidget { background-color: #2e2e2e; color: #e0e0e0; selection-background-color: #5a5a5a; selection-color: #e0e0e0; }
    QMainWindow, QDialog { background-color: #2e2e2e; }
    QGroupBox { background-color: #3c3c3c; border: 1px solid #505050; border-radius: 6px; margin-top: 6px; color: #e0e0e0; }
    QGroupBox::title { subcontrol-origin: margin; left: 7px; padding: 0px 5px 0px 5px; color: #e0e0e0; }
    QLineEdit, QComboBox, QSpinBox { background-color: #3c3c3c; border: 1px solid #505050; color: #e0e0e0; padding: 3px; }
    QLineEdit:read-only { background-color: #333333; }
    QPushButton { background-color: #4a4a4a; border: 1px solid #606060; color: #e0e0e0; padding: 5px; min-width: 70px; }
    QPushButton:hover { background-color: #5a5a5a; } QPushButton:pressed { background-color: #505050; }
    QTableWidget { background-color: #3c3c3c; color: #e0e0e0; gridline-color: #505050; border: 1px solid #505050; }
    QTableWidget::item:selected { background-color: #5a5a5a; color: #f0f0f0; }
    QHeaderView::section { background-color: #4a4a4a; color: #e0e0e0; padding: 4px; border: 1px solid #505050; }
    QStatusBar { background-color: #2e2e2e; color: #e0e0e0; }
    QMenuBar { background-color: #3c3c3c; color: #e0e0e0; } QMenuBar::item:selected { background-color: #5a5a5a; }
    QMenu { background-color: #3c3c3c; color: #e0e0e0; border: 1px solid #505050; } QMenu::item:selected { background-color: #5a5a5a; }
    QTabWidget::pane { border: 1px solid #505050; background-color: #3c3c3c; }
    QTabBar::tab { background-color: #4a4a4a; color: #e0e0e0; border: 1px solid #505050; border-bottom: none; padding: 5px; margin-right: 2px; }
    QTabBar::tab:selected { background-color: #3c3c3c; color: #ffffff; border-bottom: 1px solid #3c3c3c; }
    QTabBar::tab:!selected:hover { background-color: #5a5a5a; }
"""

ORGANIZATION_NAME = "Cooper Inc"
APPLICATION_NAME = "SC Market Tracker"
DEFAULT_PLOT_POINTS = 288
DEFAULT_THEME = "dark"
ICON_FOLDER_NAME = "icons"
APP_ICON_FOLDER_PATH = resource_path(ICON_FOLDER_NAME)
SOUND_FILE_PATH = resource_path("notification.wav")
WAREHOUSE_FILE_PATH = "wh.json"
PROJECT_DIR_MAIN_APP = os.path.dirname(
    os.path.abspath(sys.argv[0] if getattr(sys, "frozen", False) else __file__)
)
ALERTS_CHANGED_FLAG_FILE_MAIN_APP = os.path.join(
    PROJECT_DIR_MAIN_APP, ".alerts_changed_signal"
)

RESOURCE_ID_TO_ICON_FILENAME = {
    1: "power",
    2: "water",
    3: "apples",
    4: "oranges",
    5: "grapes",
    6: "grain",
    7: "steak",
    8: "sausages",
    9: "eggs",
    10: "crude-oil",
    11: "petrol",
    12: "diesel",
    13: "transport",
    14: "minerals",
    15: "bauxite",
    16: "silicon",
    17: "chemicals",
    18: "aluminium",
    19: "plastic",
    20: "processors",
    21: "electronic-components",
    22: "batteries",
    23: "displays",
    24: "smart-phones",
    25: "tablets",
    26: "laptops",
    27: "monitors",
    28: "televisions",
    29: "plant-research",
    30: "energy-research",
    31: "mining-research",
    32: "electronics-research",
    33: "breeding-research",
    34: "chemistry-research",
    35: "software",
    40: "cotton",
    41: "fabric",
    42: "iron-ore",
    43: "steel",
    44: "sand",
    45: "glass",
    46: "leather",
    47: "on-board-computer",
    48: "electric-motor",
    49: "luxury-car-interior",
    50: "car-interior",
    51: "car-body",
    52: "combustion-engine",
    53: "economy-e-car",
    54: "luxury-e-car",
    55: "economy-car",
    56: "luxury-car",
    57: "truck",
    58: "automotive-research",
    59: "fashion-research",
    60: "underwear",
    61: "gloves",
    62: "dress",
    63: "simmi-shoes",
    64: "handbags",
    65: "sneakers",
    66: "seeds",
    67: "xmas-crackers",
    68: "gold-ore",
    69: "golden-bars",
    70: "gold-watch",
    71: "necklace",
    72: "sugarcane",
    73: "ethanol",
    74: "methane",
    75: "carbon-fiber",
    76: "carbon-composite",
    77: "fuselage",
    78: "wing",
    79: "high-grade-e-components",
    80: "flight-computer",
    81: "cockpit",
    82: "attitude-control",
    83: "rocket-fuel",
    84: "fuel-tank",
    85: "solid-rocket",
    86: "rocket-engine",
    87: "heat-shield",
    88: "ion-drive",
    89: "jet-engine",
    90: "sub-orbital-second-stage",
    91: "sub-orbital-rocket2",
    92: "orbital-booster",
    93: "starship",
    94: "BFR",
    95: "jumbojet2",
    96: "private-jet",
    97: "single-engine",
    98: "quadcopter",
    99: "satellite",
    100: "aero-research",
    101: "reinforced-concrete",
    102: "bricks",
    103: "cement",
    104: "clay",
    105: "limestone",
    106: "wood",
    107: "steel-beams",
    108: "planks",
    109: "windows",
    110: "tools",
    111: "construction-units",
    112: "bulldozer",
    113: "materials-research",
    114: "robots",
    115: "cow",
    116: "pig",
    117: "milk",
    118: "coffee-beans",
    119: "coffee-ground",
    120: "vegetables",
    121: "bread",
    122: "cheese",
    123: "apple-pie",
    124: "orange-juice",
    125: "apple-cider",
    126: "ginger-beer",
    127: "pizza",
    128: "pasta",
    129: "hamburger",
    130: "lasagna",
    131: "meatballs",
    132: "cocktails",
    133: "flour",
    134: "butter",
    135: "sugar",
    136: "cocoa-beans",
    137: "dough",
    138: "gravy-boat",
    139: "fodder",
    140: "chocolate",
    141: "vegetable-oil",
    142: "salad",
    143: "samosas",
    145: "recipes",
    149: "pumpkin-soup",
    146: "pumpkin",
    148: "witch-costume",
    144: "xmas-ornament",
    147: "jack-o-lantern",
    150: "tree",
    151: "easter-bunny",
    152: "ramadan-sweets",
}


class SettingsDialog(QDialog):
    def __init__(self, current_plot_points, current_theme, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Application Settings")
        self.setModal(True)
        layout = QFormLayout(self)
        self.plot_points_spinbox = QSpinBox(self)
        self.plot_points_spinbox.setMinimum(10)
        self.plot_points_spinbox.setMaximum(2000)
        self.plot_points_spinbox.setValue(current_plot_points)
        layout.addRow("Max Data Points for Charts:", self.plot_points_spinbox)
        self.theme_combobox = QComboBox(self)
        self.theme_combobox.addItems(["Light", "Dark"])
        self.theme_combobox.setCurrentIndex(1 if current_theme.lower() == "dark" else 0)
        layout.addRow("Application Theme:", self.theme_combobox)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self
        )
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addRow(self.buttons)

    def get_settings(self):
        return (
            self.plot_points_spinbox.value(),
            self.theme_combobox.currentText().lower(),
        )


class MatplotlibCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes_price = self.fig.add_subplot(111)
        self.axes_volume = self.axes_price.twinx()
        super().__init__(self.fig)
        self.setParent(parent)

    def plot_data(self, timestamps, prices, volumes, product_name, quality):
        self.axes_price.clear()
        self.axes_volume.clear()
        if not timestamps:
            self.axes_price.set_title(f"No data for {product_name} Q{quality}")
            self.draw()
            return
        parsed_local_timestamps = []
        for ts_data in timestamps:
            ts_str = ts_data
            if isinstance(ts_str, str):
                try:
                    dt_obj = datetime.fromisoformat(ts_str)
                except ValueError:
                    print(f"Warn: Could not parse ts string for plot: {ts_str}")
                    continue
                if dt_obj.tzinfo is not None:
                    dt_obj = dt_obj.astimezone(None).replace(tzinfo=None)
                parsed_local_timestamps.append(dt_obj)
            elif isinstance(ts_str, datetime):
                if ts_str.tzinfo is not None:
                    parsed_local_timestamps.append(
                        ts_str.astimezone(None).replace(tzinfo=None)
                    )
                else:
                    parsed_local_timestamps.append(ts_str)
            else:
                print(f"Warn: Unknown ts format for plot: {ts_str}")
                continue
        if not parsed_local_timestamps:
            self.axes_price.set_title(
                f"No valid time data for {product_name} Q{quality}"
            )
            self.draw()
            return
        c_pr = "tab:blue"
        self.axes_price.set_xlabel("Time (Local)")
        self.axes_price.set_ylabel("Lowest Price ($)", color=c_pr)
        (l_pr,) = self.axes_price.plot(
            parsed_local_timestamps,
            prices,
            color=c_pr,
            marker="o",
            linestyle="-",
            label="Price",
        )
        self.axes_price.tick_params(axis="y", labelcolor=c_pr)
        c_vol = "tab:red"
        self.axes_volume.set_ylabel("Total Market Volume", color=c_vol)
        (l_vol,) = self.axes_volume.plot(
            parsed_local_timestamps,
            volumes,
            color=c_vol,
            marker="x",
            linestyle="--",
            label="Volume",
        )
        self.axes_volume.tick_params(axis="y", labelcolor=c_vol)
        self.axes_price.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M\n%m-%d"))
        self.fig.autofmt_xdate()
        self.axes_price.set_title(f"Market History for {product_name} Q{quality}")
        self.axes_price.grid(True, linestyle=":", alpha=0.7)
        hnd = [l_pr, l_vol]
        lbls = [h.get_label() for h in hnd]
        if hnd and lbls:
            self.fig.legend(
                hnd,
                lbls,
                loc="upper center",
                bbox_to_anchor=(0.5, 0.05),
                ncol=2,
                frameon=False,
            )
        try:
            self.fig.tight_layout(rect=[0, 0.07, 1, 0.95])
        except Exception as e:
            print(f"Error tight_layout: {e}")
        self.draw()


class AddProductDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add New Product")
        self.setModal(True)
        layout = QFormLayout(self)
        self.name_input = QLineEdit(self)
        self.name_input.setPlaceholderText("e.g. Power")
        layout.addRow("Product Name:", self.name_input)
        self.id_input = QLineEdit(self)
        self.id_input.setPlaceholderText("e.g. 1 (integer)")
        layout.addRow("Resource ID:", self.id_input)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self
        )
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addRow(self.buttons)

    def get_data(self):
        return self.name_input.text().strip(), self.id_input.text().strip()


class SimCompaniesHelperApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SC Market Tracker")
        self.setGeometry(100, 100, 1350, 900)
        self.details_panel_last_width = 350
        self.details_panel_visible_state = False
        self.details_panel_last_size_ratio = 0.2

        self.plot_points_limit = DEFAULT_PLOT_POINTS
        self.current_theme = DEFAULT_THEME
        self.load_settings()

        self.globally_missing_icons = set()
        self.missing_icon_warning_shown = False
        self.project_dir = os.path.dirname(os.path.abspath(__file__))
        self.alerts_changed_flag_file = os.path.join(
            self.project_dir, ".alerts_changed_signal"
        )

        self.notification_sound_effect = QSoundEffect(self)
        if os.path.exists(SOUND_FILE_PATH):
            sound_file_url = QUrl.fromLocalFile(os.path.abspath(SOUND_FILE_PATH))
            self.notification_sound_effect.setSource(sound_file_url)
        else:
            print(f"WARN_GUI: Sound file for QSoundEffect not found: {SOUND_FILE_PATH}")
        self.notification_sound_effect.setVolume(0.75)

        if not os.path.exists(ICON_FOLDER_NAME):
            try:
                os.makedirs(ICON_FOLDER_NAME)
                print(f"Created icon folder: {ICON_FOLDER_NAME}.")
            except OSError as e:
                print(f"Error creating icon folder {ICON_FOLDER_NAME}: {e}")

        self.db_manager = db_manager
        self.db_manager.initialize_db()
        self.all_products_meta = self.db_manager.get_products()

        print("DEBUG: About to call init_ui()")
        self.init_ui()
        print("DEBUG: Finished init_ui()")

        self.create_menus()
        self.apply_theme()

        self.populate_alert_product_combo()
        self.load_and_display_alerts()
        self.update_bulk_alert_options()
        self.populate_main_table()
        self.load_and_populate_warehouse()
        self.load_and_display_notification_center()

        QTimer.singleShot(100, self.show_missing_icons_warning_if_needed)
        QTimer.singleShot(100, self.make_market_columns_interactive)
        QTimer.singleShot(10, self.apply_initial_details_panel_state)

        self.gui_refresh_timer = QTimer(self)
        self.gui_refresh_timer.timeout.connect(
            self.refresh_gui_data_and_check_notifications
        )
        GUI_REFRESH_INTERVAL_SECONDS = 60
        print(
            f"DEBUG_GUI: Starting gui_refresh_timer with interval {GUI_REFRESH_INTERVAL_SECONDS}s"
        )
        self.gui_refresh_timer.start(GUI_REFRESH_INTERVAL_SECONDS * 1000)

    def make_market_columns_interactive(self):
        """Sets all market table columns to be interactively resizable by the user."""
        if hasattr(self, "market_table"):
            header = self.market_table.horizontalHeader()
            for i in range(header.count()):
                header.setSectionResizeMode(i, QHeaderView.Interactive)
            print("DEBUG: Market table columns set to Interactive mode.")

    def handle_toggle_details_panel(self):
        if self.toggle_details_button.isChecked():
            self.details_groupbox.show()
            self.toggle_details_button.setText("Hide Details")
            self.details_panel_visible_state = True
            self.restore_splitter_sizes()
        else:
            current_sizes = self.market_overview_splitter.sizes()
            if (
                self.details_groupbox.isVisible()
                and len(current_sizes) == 2
                and sum(current_sizes) > 0
            ):
                total_width = sum(current_sizes)
                if current_sizes[1] > 20:
                    self.details_panel_last_size_ratio = current_sizes[1] / total_width

            self.details_groupbox.hide()
            self.toggle_details_button.setText("Show Details")
            self.details_panel_visible_state = False
            QTimer.singleShot(
                0,
                lambda: self.market_overview_splitter.setSizes(
                    [self.market_overview_splitter.width(), 0]
                ),
            )

    def restore_splitter_sizes(self):
        if not self.details_groupbox.isVisible():
            return

        def do_resize():
            total_width = self.market_overview_splitter.width()
            if total_width <= 0:
                return

            details_width = int(total_width * self.details_panel_last_size_ratio)
            min_details_width = 150
            min_table_width = 200

            if details_width < min_details_width:
                details_width = min_details_width

            table_width = total_width - details_width
            if table_width < min_table_width:
                table_width = min_table_width
                details_width = total_width - table_width
                if details_width < 0:
                    details_width = 0

            if details_width < 0:
                details_width = 0

            self.market_overview_splitter.setSizes([table_width, details_width])
            print(
                f"DEBUG: Restored splitter sizes to: [{table_width}, {details_width}]"
            )

        QTimer.singleShot(0, do_resize)

    def init_ui(self):
        self.tab_widget = QTabWidget()
        self.setCentralWidget(self.tab_widget)

        market_overview_tab_content_widget = QWidget()

        market_overview_main_v_layout = QVBoxLayout(market_overview_tab_content_widget)

        self.toggle_details_button = QPushButton()
        self.toggle_details_button.setCheckable(True)
        self.toggle_details_button.clicked.connect(self.handle_toggle_details_panel)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(self.toggle_details_button)
        market_overview_main_v_layout.addLayout(button_layout)

        self.market_overview_splitter = QSplitter(Qt.Horizontal)

        table_groupbox = QGroupBox("Market Scan")
        table_group_layout = QVBoxLayout(table_groupbox)
        top_controls_layout = QHBoxLayout()
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Filter by product name...")
        self.filter_input.textChanged.connect(self.filter_table)
        top_controls_layout.addWidget(self.filter_input, 1)
        self.delete_product_button = QPushButton("Delete Selected Product")
        self.delete_product_button.setIcon(QIcon.fromTheme("edit-delete"))
        self.delete_product_button.clicked.connect(self.handle_delete_product)
        self.delete_product_button.setEnabled(False)
        top_controls_layout.addWidget(self.delete_product_button)
        table_group_layout.addLayout(top_controls_layout)
        self.market_table = QTableWidget()
        self.market_table.setColumnCount(11)
        self.market_table.setHorizontalHeaderLabels(
            [
                "Product Name",
                "Q",
                "Cur. Lowest Price",
                "AvgPrice (24hr)",
                "Qty@Lowest",
                "Total Vol",
                "Vol % (7d)",
                "Vol % (3d)",
                "Vol % (3h)",
                "Price % (24h)",
                "Price % (3h)",
            ]
        )
        self.market_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.market_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.market_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.market_table.itemClicked.connect(self.on_table_item_clicked)
        self.market_table.itemDoubleClicked.connect(
            self.on_market_table_item_double_clicked
        )
        self.market_table.selectionModel().selectionChanged.connect(
            self.on_market_table_selection_changed
        )
        self.market_table.setSortingEnabled(True)

        self.market_table.setColumnWidth(0, 180)
        self.market_table.setColumnWidth(1, 35)
        self.market_table.setColumnWidth(2, 90)
        self.market_table.setColumnWidth(3, 90)
        self.market_table.setColumnWidth(4, 90)
        self.market_table.setColumnWidth(5, 100)
        self.market_table.setColumnWidth(6, 90)
        self.market_table.setColumnWidth(7, 90)
        self.market_table.setColumnWidth(8, 90)
        self.market_table.setColumnWidth(9, 100)
        self.market_table.setColumnWidth(10, 100)

        market_table_header = self.market_table.horizontalHeader()
        market_table_header.setSectionResizeMode(0, QHeaderView.Stretch)
        for i in range(1, self.market_table.columnCount()):
            market_table_header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

        table_group_layout.addWidget(self.market_table)
        self.market_overview_splitter.addWidget(table_groupbox)

        self.details_groupbox = QGroupBox("Product Details")
        details_main_layout = QVBoxLayout(self.details_groupbox)
        form_l = QFormLayout()
        self.detail_product_name = QLineEdit()
        self.detail_product_name.setReadOnly(True)
        form_l.addRow("Product:", self.detail_product_name)
        self.detail_quality = QLineEdit()
        self.detail_quality.setReadOnly(True)
        form_l.addRow("Quality:", self.detail_quality)
        self.detail_current_lowest = QLineEdit()
        self.detail_current_lowest.setReadOnly(True)
        form_l.addRow("Cur. Lowest $:", self.detail_current_lowest)
        self.detail_qty_at_lowest = QLineEdit()
        self.detail_qty_at_lowest.setReadOnly(True)
        form_l.addRow("Qty @ Lowest:", self.detail_qty_at_lowest)
        self.detail_avg_vol_7d = QLineEdit()
        self.detail_avg_vol_7d.setReadOnly(True)
        form_l.addRow("Avg Vol (7d):", self.detail_avg_vol_7d)
        self.detail_avg_price_7d = QLineEdit()
        self.detail_avg_price_7d.setReadOnly(True)
        form_l.addRow("Avg Min Price(7d):", self.detail_avg_price_7d)
        self.detail_last_fetch_time = QLineEdit()
        self.detail_last_fetch_time.setReadOnly(True)
        form_l.addRow("Last Fetched (Loc):", self.detail_last_fetch_time)
        details_main_layout.addLayout(form_l)
        self.plot_canvas = MatplotlibCanvas(self)
        self.nav_toolbar = NavigationToolbar(self.plot_canvas, self)
        details_main_layout.addWidget(self.nav_toolbar)
        details_main_layout.addWidget(self.plot_canvas)
        self.market_overview_splitter.addWidget(self.details_groupbox)

        if self.details_panel_visible_state:
            self.details_groupbox.show()
            self.toggle_details_button.setText("Hide Details")
            self.toggle_details_button.setChecked(True)
            self.market_overview_splitter.setStretchFactor(0, 2)
            self.market_overview_splitter.setStretchFactor(1, 1)
        else:
            self.details_groupbox.hide()
            self.toggle_details_button.setText("Show Details")
            self.toggle_details_button.setChecked(False)
            self.market_overview_splitter.setStretchFactor(0, 1)
            self.market_overview_splitter.setStretchFactor(1, 0)

        market_overview_main_v_layout.addWidget(self.market_overview_splitter)
        market_overview_tab_content_widget.setLayout(market_overview_main_v_layout)
        self.tab_widget.addTab(market_overview_tab_content_widget, "Market Overview")

        wh_tab_w = QWidget()
        wh_tab_l = QVBoxLayout(wh_tab_w)
        top_wh_l = QHBoxLayout()
        self.refresh_warehouse_button = QPushButton("Refresh Warehouse Data")
        self.refresh_warehouse_button.setIcon(QIcon.fromTheme("view-refresh"))
        self.refresh_warehouse_button.clicked.connect(self.load_and_populate_warehouse)
        top_wh_l.addWidget(self.refresh_warehouse_button)
        top_wh_l.addStretch(1)
        self.warehouse_total_value_label = QLabel("Total WH Value: $0.00")
        self.warehouse_total_pl_label = QLabel("Total WH P/L: $0.00")
        top_wh_l.addWidget(self.warehouse_total_value_label)
        top_wh_l.addWidget(self.warehouse_total_pl_label)
        wh_tab_l.addLayout(top_wh_l)
        self.warehouse_table = QTableWidget()
        self.warehouse_table.setColumnCount(9)
        self.warehouse_table.setHorizontalHeaderLabels(
            [
                "Icon",
                "Name",
                "Q",
                "Qty",
                "Acq. Cost",
                "Cur. Price",
                "Cur. Value",
                "P/L",
                "P/L %",
            ]
        )
        self.warehouse_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.warehouse_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.warehouse_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.warehouse_table.setSortingEnabled(True)
        wh_tbl_hdr = self.warehouse_table.horizontalHeader()
        wh_tbl_hdr.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        wh_tbl_hdr.setSectionResizeMode(1, QHeaderView.Stretch)
        for i in range(2, 9):
            wh_tbl_hdr.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        wh_tab_l.addWidget(self.warehouse_table)
        self.tab_widget.addTab(wh_tab_w, "My Warehouse")
        self.alerts_tab_content_widget = QWidget()
        alerts_tab_main_layout = QVBoxLayout(self.alerts_tab_content_widget)

        add_alert_groupbox = QGroupBox("Add New Single Alert")
        add_alert_form_layout = QFormLayout(add_alert_groupbox)
        self.alert_product_combo = QComboBox()
        add_alert_form_layout.addRow("Product:", self.alert_product_combo)
        self.alert_quality_spinbox = QSpinBox()
        self.alert_quality_spinbox.setMinimum(-1)
        self.alert_quality_spinbox.setMaximum(20)
        self.alert_quality_spinbox.setValue(0)
        self.alert_quality_spinbox.setSpecialValueText("Any (Q-1)")
        add_alert_form_layout.addRow(
            "Quality (-1 for Any):", self.alert_quality_spinbox
        )
        self.alert_metric_combo = QComboBox()
        self.alert_metric_combo.addItems(
            [
                "Price (Absolute)",
                "Volume (Absolute)",
                "Price Change %",
                "Volume Change %",
            ]
        )
        self.alert_metric_combo.currentIndexChanged.connect(
            self.update_alert_condition_options
        )
        add_alert_form_layout.addRow("Metric:", self.alert_metric_combo)
        self.alert_condition_combo = QComboBox()
        add_alert_form_layout.addRow("Condition:", self.alert_condition_combo)
        self.alert_threshold_input = QLineEdit()
        self.alert_threshold_input.setPlaceholderText("e.g., 150 or 30 (for %)")
        add_alert_form_layout.addRow("Threshold Val/Pct:", self.alert_threshold_input)
        self.alert_comparison_period_label = QLabel("Comparison Period:")
        self.alert_comparison_period_spinbox = QSpinBox()
        self.alert_comparison_period_spinbox.setMinimum(1)
        self.alert_comparison_period_spinbox.setMaximum(168)
        self.alert_comparison_period_spinbox.setValue(24)
        self.alert_comparison_period_spinbox.setSuffix(" hours")
        add_alert_form_layout.addRow(
            self.alert_comparison_period_label, self.alert_comparison_period_spinbox
        )
        self.alert_custom_message_input = QLineEdit()
        self.alert_custom_message_input.setPlaceholderText("(Optional)")
        add_alert_form_layout.addRow("Custom Message:", self.alert_custom_message_input)
        self.add_alert_button = QPushButton("Add Single Alert")
        self.add_alert_button.setIcon(QIcon.fromTheme("list-add"))
        self.add_alert_button.clicked.connect(self.handle_add_alert)
        add_alert_form_layout.addRow(self.add_alert_button)
        alerts_tab_main_layout.addWidget(add_alert_groupbox)

        bulk_alert_groupbox = QGroupBox("Create Bulk Alert for All Products")
        bulk_alert_form_layout = QFormLayout(bulk_alert_groupbox)

        self.bulk_alert_metric_combo = QComboBox()
        self.bulk_alert_metric_combo.addItems(["Volume Change %", "Price Change %"])
        self.bulk_alert_metric_combo.currentIndexChanged.connect(
            self.update_bulk_alert_options
        )
        bulk_alert_form_layout.addRow("Metric:", self.bulk_alert_metric_combo)

        self.bulk_alert_condition_combo = QComboBox()
        bulk_alert_form_layout.addRow("Condition:", self.bulk_alert_condition_combo)

        self.bulk_alert_threshold_input = QLineEdit()
        self.bulk_alert_threshold_input.setPlaceholderText("e.g., 30 (for 30%)")
        bulk_alert_form_layout.addRow(
            "Threshold Percent:", self.bulk_alert_threshold_input
        )

        self.bulk_alert_comparison_period_spinbox = QSpinBox()
        self.bulk_alert_comparison_period_spinbox.setMinimum(1)
        self.bulk_alert_comparison_period_spinbox.setMaximum(7 * 24)
        self.bulk_alert_comparison_period_spinbox.setValue(24)
        self.bulk_alert_comparison_period_spinbox.setSuffix(" hours")
        bulk_alert_form_layout.addRow(
            "Comparison Period:", self.bulk_alert_comparison_period_spinbox
        )

        self.create_bulk_alert_button = QPushButton("Create Alerts for ALL Products")
        self.create_bulk_alert_button.setIcon(QIcon.fromTheme("document-new"))
        self.create_bulk_alert_button.clicked.connect(self.handle_create_bulk_alerts)
        bulk_alert_form_layout.addRow(self.create_bulk_alert_button)

        alerts_tab_main_layout.addWidget(bulk_alert_groupbox)

        active_alerts_groupbox = QGroupBox("Active Alerts")
        active_alerts_layout = QVBoxLayout(active_alerts_groupbox)

        self.delete_selected_alerts_button = QPushButton("Delete Selected Alert(s)")
        self.delete_selected_alerts_button.setIcon(QIcon.fromTheme("edit-delete"))
        self.delete_selected_alerts_button.clicked.connect(
            self.handle_delete_selected_alerts
        )
        self.delete_selected_alerts_button.setEnabled(False)
        active_alerts_layout.addWidget(
            self.delete_selected_alerts_button, 0, Qt.AlignRight
        )

        self.alerts_table = QTableWidget()
        self.alerts_table.setColumnCount(6)
        self.alerts_table.setHorizontalHeaderLabels(
            ["Product", "Q", "Metric", "Condition", "Threshold", "Message"]
        )
        self.alerts_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.alerts_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.alerts_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.alerts_table.selectionModel().selectionChanged.connect(
            self.on_alerts_table_selection_changed
        )

        alert_header = self.alerts_table.horizontalHeader()
        alert_header.setSectionResizeMode(0, QHeaderView.Stretch)
        for i in range(1, 6):
            alert_header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

        active_alerts_layout.addWidget(self.alerts_table)
        alerts_tab_main_layout.addWidget(active_alerts_groupbox)

        self.tab_widget.addTab(self.alerts_tab_content_widget, "Manage Alerts")

        self.notification_center_tab_content_widget = QWidget()
        notification_center_main_layout = QVBoxLayout(
            self.notification_center_tab_content_widget
        )
        nc_top_controls_layout = QHBoxLayout()
        self.clear_acknowledged_button = QPushButton("Clear Viewed Notifications")
        self.clear_acknowledged_button.setIcon(QIcon.fromTheme("edit-clear-list"))
        self.clear_acknowledged_button.clicked.connect(
            self.handle_clear_acknowledged_notifications
        )
        nc_top_controls_layout.addWidget(self.clear_acknowledged_button)
        nc_top_controls_layout.addStretch(1)
        notification_center_main_layout.addLayout(nc_top_controls_layout)
        self.notifications_table = QTableWidget()
        self.notifications_table.setColumnCount(5)
        self.notifications_table.setHorizontalHeaderLabels(
            ["Time (Local)", "Product", "Q", "Notification", "Status"]
        )
        self.notifications_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.notifications_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.notifications_table.setWordWrap(True)
        self.notifications_table.verticalHeader().setDefaultSectionSize(40)
        self.notifications_table.setSortingEnabled(True)
        nc_tbl_hdr = self.notifications_table.horizontalHeader()
        nc_tbl_hdr.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        nc_tbl_hdr.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        nc_tbl_hdr.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        nc_tbl_hdr.setSectionResizeMode(3, QHeaderView.Stretch)
        nc_tbl_hdr.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        notification_center_main_layout.addWidget(self.notifications_table)
        self.tab_widget.addTab(
            self.notification_center_tab_content_widget, "Notification Center"
        )
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("App UI Initialized.")

    def handle_clear_acknowledged_notifications(self):
        reply = QMessageBox.question(
            self,
            "Confirm Clear Notifications",
            "Are you sure you want to clear all 'Viewed' notifications from the log?\n"
            "This action cannot be undone.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )

        if reply == QMessageBox.Yes:
            if self.db_manager.delete_acknowledged_notifications():
                self.status_bar.showMessage("Cleared viewed notifications.", 3000)
                self.load_and_display_notification_center()
            else:
                QMessageBox.critical(
                    self,
                    "Database Error",
                    "Failed to clear acknowledged notifications.",
                )

    def on_market_table_item_double_clicked(self, item: QTableWidgetItem):
        """Handles double-click on an item in the market_table to open its SimCompanies market page."""
        if not item:
            return

        row = item.row()
        product_info_item = self.market_table.item(row, 0)
        if not product_info_item:
            print("WARN: Could not get product info item for double-clicked row.")
            return

        item_data = product_info_item.data(Qt.UserRole)
        if (
            not item_data
            or "resource_id" not in item_data
            or "quality" not in item_data
        ):
            print(
                f"WARN: Missing resource_id or quality in UserRole data for row {row}. Data: {item_data}"
            )
            self.status_bar.showMessage("Error: Product data incomplete for URL.", 3000)
            return

        resource_id = item_data["resource_id"]
        quality_val = item_data["quality"]
        product_name = item_data.get("name", f"ID {resource_id}")

        market_url = f"https://www.simcompanies.com/market/resource/{resource_id}/?quality={quality_val}"

        print(
            f"INFO: Opening market URL for {product_name} Q{quality_val}: {market_url}"
        )
        self.status_bar.showMessage(
            f"Opening market page for {product_name} Q{quality_val}...", 3000
        )

        try:
            webbrowser.open_new_tab(market_url)
        except Exception as e:
            print(f"ERROR: Could not open URL {market_url}: {e}")
            QMessageBox.warning(
                self,
                "Error Opening URL",
                f"Could not open the market page in your browser.\nURL: {market_url}\nError: {e}",
            )
            self.status_bar.showMessage(f"Failed to open market page.", 3000)

    def apply_initial_details_panel_state(self):
        """Applies the correct splitter sizes based on initial visibility."""
        print(
            f"DEBUG: apply_initial_details_panel_state called. Visible state: {self.details_panel_visible_state}"
        )
        if self.details_panel_visible_state:
            self.restore_splitter_sizes()
        else:

            def hide_details_fully():
                current_sizes = self.market_overview_splitter.sizes()
                if (
                    len(current_sizes) == 2
                    and self.market_overview_splitter.width() > 0
                ):
                    print(
                        f"DEBUG: Hiding details fully. Current splitter total width: {current_sizes[0] + current_sizes[1]}"
                    )
                    self.market_overview_splitter.setSizes(
                        [current_sizes[0] + current_sizes[1], 0]
                    )
                else:
                    print(
                        f"DEBUG: Splitter not ready for full hide sizing, width: {self.market_overview_splitter.width()}"
                    )

            QTimer.singleShot(0, hide_details_fully)

    def on_alerts_table_selection_changed(self, selected, deselected):
        """Enable/disable the 'Delete Selected Alerts' button based on selection."""
        if self.alerts_table.selectionModel().hasSelection():
            self.delete_selected_alerts_button.setEnabled(True)
        else:
            self.delete_selected_alerts_button.setEnabled(False)

    def handle_delete_selected_alerts(self):
        selected_rows_indices = sorted(
            list(set(index.row() for index in self.alerts_table.selectedIndexes())),
            reverse=True,
        )

        if not selected_rows_indices:
            QMessageBox.information(
                self, "No Selection", "Please select one or more alerts to delete."
            )
            return

        alert_ids_to_delete = []
        alert_descriptions = []
        for row_index in selected_rows_indices:
            product_name_item = self.alerts_table.item(row_index, 0)
            if product_name_item and product_name_item.data(Qt.UserRole):
                alert_id = product_name_item.data(Qt.UserRole)
                alert_ids_to_delete.append(alert_id)
                q_item = self.alerts_table.item(row_index, 1)
                metric_item = self.alerts_table.item(row_index, 2)
                condition_item = self.alerts_table.item(row_index, 3)
                threshold_item = self.alerts_table.item(row_index, 4)
                desc = f"- {product_name_item.text()} Q{q_item.text()}: {metric_item.text()} {condition_item.text()} {threshold_item.text()}"
                alert_descriptions.append(desc)

        if not alert_ids_to_delete:
            QMessageBox.warning(
                self, "Error", "Could not retrieve IDs for selected alerts."
            )
            return

        confirm_text = (
            f"Are you sure you want to delete the following {len(alert_ids_to_delete)} alert(s)?\n\n"
            + "\n".join(alert_descriptions[:5])
        )
        if len(alert_descriptions) > 5:
            confirm_text += f"\n...and {len(alert_descriptions) - 5} more."

        reply = QMessageBox.question(
            self,
            "Confirm Multiple Deletion",
            confirm_text,
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )

        if reply == QMessageBox.Yes:
            deleted_count = 0
            failed_count = 0
            for alert_id in alert_ids_to_delete:
                if self.db_manager.delete_alert(alert_id):
                    deleted_count += 1
                else:
                    failed_count += 1

            self.status_bar.showMessage(
                f"{deleted_count} alert(s) deleted. {failed_count} failed.", 5000
            )
            if failed_count > 0:
                QMessageBox.warning(
                    self,
                    "Deletion Issue",
                    f"Successfully deleted {deleted_count} alerts. Failed to delete {failed_count} alerts.",
                )

            self.load_and_display_alerts()
            self.touch_alerts_flag_file()
            self.delete_selected_alerts_button.setEnabled(False)

    def touch_alerts_flag_file(self):
        try:
            with open(self.alerts_changed_flag_file, "a") as f:
                os.utime(self.alerts_changed_flag_file, None)
            print(
                f"DEBUG_GUI: Touched alerts flag file: {self.alerts_changed_flag_file}"
            )
        except Exception as e:
            print(
                f"ERROR_GUI: Could not touch alerts flag file: {self.alerts_changed_flag_file} - {e}"
            )

    def play_notification_sound(self):
        if self.notification_sound_effect.source().isEmpty():
            print(
                f"WARN_GUI: QSoundEffect source is empty. Attempting to reload or file not found: {SOUND_FILE_PATH}"
            )
            if os.path.exists(SOUND_FILE_PATH):
                sound_file_url = QUrl.fromLocalFile(os.path.abspath(SOUND_FILE_PATH))
                self.notification_sound_effect.setSource(sound_file_url)
            else:
                return

        if self.notification_sound_effect.isLoaded():
            print(
                f"DEBUG_GUI: Playing sound via QSoundEffect: {self.notification_sound_effect.source().toLocalFile()}"
            )
            self.notification_sound_effect.play()
        else:
            status = self.notification_sound_effect.status()
            print(
                f"ERROR_GUI: QSoundEffect not loaded for {SOUND_FILE_PATH}. Status: {status}"
            )
            if status == QSoundEffect.Error:
                print(
                    f"QSoundEffect load error. Ensure format (e.g., WAV) is supported and QtMultimedia backend/plugins (like GStreamer) are installed."
                )

    def send_gui_desktop_notification(
        self, title, message, icon_name="dialog-information"
    ):
        """Sends a desktop notification FROM THE GUI PROCESS and plays a sound."""
        try:
            title_str = str(title)
            message_str = str(message)
            command = [
                "notify-send",
                "-u",
                "normal",
                "-i",
                icon_name,
                title_str,
                message_str,
            ]
            print(f"DEBUG_GUI: Attempting to send notification with command: {command}")
            subprocess.run(command, check=True, timeout=5)
            print(f"DEBUG_GUI: Sent desktop notification: '{title_str}'")

            self.play_notification_sound()

        except FileNotFoundError:
            print("GUI ERROR: 'notify-send' command not found.")
        except subprocess.TimeoutExpired:
            print("GUI ERROR: Timeout sending notification.")
        except subprocess.CalledProcessError as e:
            print(
                f"GUI ERROR sending notification. Cmd: '{e.cmd}'. RetCode: {e.returncode}."
            )
        except Exception as e:
            print(f"GUI ERROR: Unexpected error in send_gui_desktop_notification: {e}")

    def check_and_display_new_notifications(self):
        print(
            f"DEBUG_GUI: check_and_display_new_notifications called at {datetime.now().strftime('%H:%M:%S')}"
        )
        new_notifications = self.db_manager.get_unacknowledged_notifications()
        print(
            f"DEBUG_GUI: Found {len(new_notifications)} unacknowledged notifications in DB."
        )

        if not new_notifications:
            print(
                "DEBUG_GUI: No new unacknowledged notifications found, returning from check_and_display."
            )
            return

        self.status_bar.showMessage(
            f"{len(new_notifications)} new alert(s) triggered!", 7000
        )

        for notif_data in new_notifications:
            print(
                f"DEBUG_GUI: Processing unacknowledged notification log ID: {notif_data['id']} for alert ID: {notif_data['alert_id']}"
            )

            self.send_gui_desktop_notification(
                notif_data["message_title"], notif_data["message_body"]
            )
            print(
                f"DEBUG_GUI: Desktop notification (and sound) attempt for log ID: {notif_data['id']} completed."
            )

            if self.db_manager.acknowledge_notification(notif_data["id"]):
                print(
                    f"DEBUG_GUI: Successfully acknowledged notification log ID: {notif_data['id']} in DB."
                )
            else:
                print(
                    f"DEBUG_GUI: Failed to acknowledge or already acknowledged notification log ID: {notif_data['id']} in DB."
                )

    def load_and_display_notification_center(self):
        print(
            f"DEBUG_GUI: load_and_display_notification_center called at {datetime.now().strftime('%H:%M:%S')}"
        )
        self.notifications_table.setSortingEnabled(False)
        self.notifications_table.setRowCount(0)
        all_notifications = self.db_manager.get_all_notifications_sorted(limit=100)
        print(
            f"DEBUG_GUI: Fetched {len(all_notifications)} total notifications for display in center."
        )
        if not all_notifications:
            print("DEBUG_GUI: No notifications to display in center.")
            self.notifications_table.setSortingEnabled(True)
            return
        for row_idx, notif_data in enumerate(all_notifications):
            self.notifications_table.insertRow(row_idx)
            triggered_at_str = notif_data["triggered_at"]
            dt_display_str = "N/A"
            try:
                dt_obj = datetime.fromisoformat(triggered_at_str)
                dt_display_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                dt_display_str = triggered_at_str
            self.notifications_table.setItem(
                row_idx, 0, QTableWidgetItem(dt_display_str)
            )
            self.notifications_table.setItem(
                row_idx, 1, QTableWidgetItem(notif_data["product_name"])
            )
            self.notifications_table.setItem(
                row_idx, 2, QTableWidgetItem(notif_data["quality_display"])
            )
            msg_item = QTableWidgetItem(notif_data["message_body"])
            self.notifications_table.setItem(row_idx, 3, msg_item)
            status_text = "Viewed" if notif_data["is_acknowledged"] else "New"
            self.notifications_table.setItem(row_idx, 4, QTableWidgetItem(status_text))
        self.notifications_table.resizeRowsToContents()
        self.notifications_table.setSortingEnabled(True)

    def refresh_gui_data_and_check_notifications(self):
        print(
            f"DEBUG_GUI: TIMER FIRED - refresh_gui_data_and_check_notifications called at {datetime.now().strftime('%H:%M:%S')}"
        )
        self.all_products_meta = self.db_manager.get_products()
        self.populate_main_table()
        self.load_and_populate_warehouse()

        print(
            f"DEBUG_GUI: About to call check_and_display_new_notifications from timer slot"
        )
        self.check_and_display_new_notifications()
        print(f"DEBUG_GUI: Finished check_and_display_new_notifications call.")

        print(
            f"DEBUG_GUI: About to call load_and_display_notification_center from timer slot"
        )
        self.load_and_display_notification_center()

        self.status_bar.showMessage(
            f"GUI data refreshed at {datetime.now().strftime('%H:%M:%S')}", 3000
        )

    def check_and_set_icon(self, table_item, resource_id, for_table_type="Market"):
        icon_base_filename = RESOURCE_ID_TO_ICON_FILENAME.get(resource_id)
        if icon_base_filename:
            icon_path = os.path.join(ICON_FOLDER_NAME, f"{icon_base_filename}.png")
            if os.path.exists(icon_path):
                table_item.setIcon(QIcon(icon_path))
            else:
                if icon_path not in self.globally_missing_icons:
                    print(
                        f"WARN: ({for_table_type}) Icon not found: {icon_path} for res_id {resource_id}"
                    )
                    self.globally_missing_icons.add(icon_path)
                    self.missing_icon_warning_shown = False

    def show_missing_icons_warning_if_needed(self):
        if self.globally_missing_icons and not self.missing_icon_warning_shown:
            missing_list_str = "\n".join(sorted(list(self.globally_missing_icons)))
            QMessageBox.warning(
                self,
                "Missing Icons",
                f"Icon files not found in '{ICON_FOLDER_NAME}':\n\n{missing_list_str}",
            )
            self.missing_icon_warning_shown = True
            self.status_bar.showMessage(
                "Warning: Some product icons are missing.", 10000
            )

    def load_settings(self):
        settings = QSettings(ORGANIZATION_NAME, APPLICATION_NAME)
        self.plot_points_limit = settings.value(
            "plot_points_limit", DEFAULT_PLOT_POINTS, type=int
        )
        self.current_theme = settings.value("current_theme", DEFAULT_THEME, type=str)
        print(
            f"Loaded settings: Plot Points={self.plot_points_limit}, Theme='{self.current_theme}'"
        )

    def save_settings(self):
        settings = QSettings(ORGANIZATION_NAME, APPLICATION_NAME)
        settings.setValue("plot_points_limit", self.plot_points_limit)
        settings.setValue("current_theme", self.current_theme)
        print(
            f"Saved settings: Plot Points={self.plot_points_limit}, Theme='{self.current_theme}'"
        )

    def create_menus(self):
        menu_bar = self.menuBar()
        file_menu = menu_bar.addMenu("&File")
        settings_action = QAction(
            QIcon.fromTheme("preferences-system"), "&Settings...", self
        )
        settings_action.setStatusTip("Configure application settings")
        settings_action.triggered.connect(self.show_settings_dialog)
        file_menu.addAction(settings_action)
        file_menu.addSeparator()
        add_product_action = QAction(
            QIcon.fromTheme("list-add"), "&Add Product to Track...", self
        )
        add_product_action.setStatusTip("Add new product to tracking list and DB")
        add_product_action.triggered.connect(self.show_add_product_dialog)
        file_menu.addAction(add_product_action)
        file_menu.addSeparator()
        exit_action = QAction(QIcon.fromTheme("application-exit"), "&Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.setStatusTip("Exit application")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        view_menu = menu_bar.addMenu("&View")
        self.toggle_theme_action = QAction("", self, checkable=True)
        if self.current_theme == "dark":
            self.toggle_theme_action.setChecked(True)
            self.toggle_theme_action.setText("Switch to Light Theme")
        else:
            self.toggle_theme_action.setChecked(False)
            self.toggle_theme_action.setText("Switch to Dark Theme")
        self.toggle_theme_action.triggered.connect(self.toggle_theme_action_triggered)
        view_menu.addAction(self.toggle_theme_action)

    def show_settings_dialog(self):
        dialog = SettingsDialog(self.plot_points_limit, self.current_theme, self)
        if dialog.exec_() == QDialog.Accepted:
            new_plot_points, new_theme = dialog.get_settings()
            settings_changed = False
            if self.plot_points_limit != new_plot_points:
                self.plot_points_limit = new_plot_points
                settings_changed = True
            current_item_widget = self.market_table.item(
                self.market_table.currentRow(), 0
            )
            if current_item_widget:
                self.on_table_item_clicked(current_item_widget)
            if self.current_theme != new_theme:
                self.current_theme = new_theme
                self.apply_theme()
            if self.current_theme == "dark":
                self.toggle_theme_action.setChecked(True)
                self.toggle_theme_action.setText("Switch to Light Theme")
            else:
                self.toggle_theme_action.setChecked(False)
                self.toggle_theme_action.setText("Switch to Dark Theme")
            settings_changed = True
            if settings_changed:
                self.save_settings()
            self.status_bar.showMessage("Settings updated.", 3000)

    def toggle_theme_action_triggered(self):
        if self.toggle_theme_action.isChecked():
            self.current_theme = "dark"
            self.toggle_theme_action.setText("Switch to Light Theme")
        else:
            self.current_theme = "light"
            self.toggle_theme_action.setText("Switch to Dark Theme")
        self.apply_theme()
        self.save_settings()

    def apply_theme(self):
        app = QApplication.instance()
        if app:
            app.setStyleSheet(
                DARK_THEME_QSS if self.current_theme == "dark" else LIGHT_THEME_QSS
            )

    def show_add_product_dialog(self):
        dialog = AddProductDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            name, resource_id_str = dialog.get_data()
            if not name or not resource_id_str:
                QMessageBox.warning(self, "Input Error", "Name and ID required.")
                return
            try:
                resource_id = int(resource_id_str)
            except ValueError:
                QMessageBox.warning(self, "Input Error", "Resource ID must be integer.")
                return
            if resource_id <= 0:
                QMessageBox.warning(
                    self, "Input Error", "Resource ID must be positive."
                )
                return
            if any(p["resource_id"] == resource_id for p in self.all_products_meta):
                QMessageBox.information(
                    self, "Product Info", f"Product ID {resource_id} already known."
                )
            self.db_manager.add_product_if_not_exists(name, resource_id)
            self.status_bar.showMessage(
                f"Added/verified product: {name} (ID: {resource_id})", 5000
            )
            self.all_products_meta = self.db_manager.get_products()
            self.populate_alert_product_combo()
            QMessageBox.information(
                self,
                "Product Processed",
                f"{name} (ID: {resource_id}) processed.\nFetcher service may need restart for new items.",
            )
            self.populate_main_table()
            self.touch_alerts_flag_file()

    def on_market_table_selection_changed(self, selected, deselected):
        if self.market_table.selectionModel().hasSelection():
            self.delete_product_button.setEnabled(True)
        else:
            self.delete_product_button.setEnabled(False)

    def handle_delete_product(self):
        selected_items = self.market_table.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "No Selection", "Select product to delete.")
            return
        name_item = self.market_table.item(selected_items[0].row(), 0)
        if not name_item:
            return
        item_data = name_item.data(Qt.UserRole)
        if not item_data:
            QMessageBox.critical(self, "Error", "Could not retrieve product data.")
            return
        product_db_id = item_data["db_id"]
        product_name = item_data["name"]
        msg_box = QMessageBox(self)
        msg_box.setIcon(QMessageBox.Warning)
        msg_box.setWindowTitle("Confirm Product Deletion")
        msg_box.setText(f"Stop tracking '{product_name}' and remove from fetch list?")
        msg_box.setInformativeText("Delete historical market data too?")
        del_all_btn = msg_box.addButton(
            "Delete Product & All History", QMessageBox.DestructiveRole
        )
        del_prod_btn = msg_box.addButton(
            "Stop Tracking (Keep History)", QMessageBox.AcceptRole
        )
        cancel_btn = msg_box.addButton(QMessageBox.Cancel)
        msg_box.setDefaultButton(cancel_btn)
        msg_box.exec_()
        clicked = msg_box.clickedButton()
        del_hist = False
        proceed = False
        if clicked == del_all_btn:
            del_hist = True
            proceed = True
        elif clicked == del_prod_btn:
            del_hist = False
            proceed = True
        else:
            return
        if proceed:
            if del_hist:
                if self.db_manager.delete_market_history_for_product(product_db_id):
                    self.status_bar.showMessage(
                        f"Deleted history for '{product_name}'.", 4000
                    )
                else:
                    QMessageBox.critical(
                        self,
                        "DB Error",
                        f"Failed to delete history for '{product_name}'.",
                    )
                    return
            if self.db_manager.delete_product(product_db_id):
                self.status_bar.showMessage(
                    f"'{product_name}' removed from tracking.", 5000
                )
                QMessageBox.information(
                    self,
                    "Product Removed",
                    f"'{product_name}' removed.\nFetcher will stop fetching it after restart/refresh.",
                )
                self.all_products_meta = self.db_manager.get_products()
                self.populate_main_table()
                self.load_and_populate_warehouse()
                self.clear_details_panel()
                self.delete_product_button.setEnabled(False)
                self.populate_alert_product_combo()
                self.load_and_display_alerts()
                self.touch_alerts_flag_file()
            else:
                QMessageBox.critical(
                    self, "DB Error", f"Failed to remove '{product_name}'."
                )

    def filter_table(self, text):
        for i in range(self.market_table.rowCount()):
            item = self.market_table.item(i, 0)
            if item:
                self.market_table.setRowHidden(
                    i, not (text.lower() in item.text().lower())
                )
            else:
                self.market_table.setRowHidden(i, True)

    def populate_alert_product_combo(self):
        self.alert_product_combo.clear()
        if not self.all_products_meta:
            self.all_products_meta = self.db_manager.get_products()
        for product in sorted(self.all_products_meta, key=lambda p: p["name"]):
            self.alert_product_combo.addItem(product["name"], userData=product["id"])

    def update_alert_condition_options(self, index=None):
        metric_text = self.alert_metric_combo.currentText()
        self.alert_condition_combo.clear()
        if "Absolute" in metric_text:
            self.alert_condition_combo.addItems(["Drops Below", "Rises Above"])
            if hasattr(self, "alert_comparison_period_label"):
                self.alert_comparison_period_label.setVisible(False)
            if hasattr(self, "alert_comparison_period_spinbox"):
                self.alert_comparison_period_spinbox.setVisible(False)
            if hasattr(self, "alert_threshold_input"):
                self.alert_threshold_input.setPlaceholderText(
                    "e.g., 150 (absolute value)"
                )
        elif "Change %" in metric_text:
            self.alert_condition_combo.addItems(["Increases by >", "Decreases by >"])
            if hasattr(self, "alert_comparison_period_label"):
                self.alert_comparison_period_label.setVisible(True)
            if hasattr(self, "alert_comparison_period_spinbox"):
                self.alert_comparison_period_spinbox.setVisible(True)
            if hasattr(self, "alert_threshold_input"):
                self.alert_threshold_input.setPlaceholderText("e.g., 30 (for 30%)")

    def handle_add_alert(self):
        product_db_id = self.alert_product_combo.currentData()
        if product_db_id is None:
            QMessageBox.warning(self, "Input Error", "Please select a product.")
            return
        quality_str = self.alert_quality_spinbox.text()
        quality = -1
        if quality_str != "Any (Q-1)":
            try:
                quality = int(quality_str)
            except ValueError:
                QMessageBox.warning(self, "Input Error", "Invalid quality.")
                return
            if not (-1 <= quality <= 20):
                QMessageBox.warning(self, "Input Error", "Quality out of range.")
                return
        metric_text = self.alert_metric_combo.currentText()
        condition_text = self.alert_condition_combo.currentText()
        metric_db_val = ""
        condition_db_val = ""
        comparison_period_hours = None
        if "Absolute" in metric_text:
            metric_db_val = "price" if "Price" in metric_text else "volume"
            condition_db_val = "below" if "Below" in condition_text else "above"
        elif "Change %" in metric_text:
            metric_db_val = (
                "price_change_percent"
                if "Price" in metric_text
                else "volume_change_percent"
            )
            condition_db_val = (
                "increase" if "Increases" in condition_text else "decrease"
            )
            comparison_period_hours = self.alert_comparison_period_spinbox.value()
        else:
            QMessageBox.critical(
                self, "Internal Error", "Unrecognized alert metric type."
            )
            return
        try:
            threshold_value = float(self.alert_threshold_input.text())
            if "%" in metric_text and (threshold_value <= 0 or threshold_value > 1000):
                QMessageBox.warning(
                    self, "Input Error", "Percentage threshold positive (1-1000)."
                )
                return
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Threshold must be a number.")
            return
        custom_message = self.alert_custom_message_input.text().strip() or None
        alert_id = self.db_manager.add_alert(
            product_db_id,
            quality,
            metric_db_val,
            condition_db_val,
            threshold_value,
            comparison_period_hours,
            custom_message,
        )
        if alert_id:
            self.status_bar.showMessage(f"Alert added (ID: {alert_id}).", 3000)
            self.load_and_display_alerts()
            self.alert_threshold_input.clear()
            self.alert_custom_message_input.clear()
            self.touch_alerts_flag_file()
        else:
            QMessageBox.critical(self, "Database Error", "Failed to add alert.")

    def handle_delete_alert(self, alert_id):
        reply = QMessageBox.question(
            self,
            "Confirm Delete Alert",
            f"Are you sure you want to delete alert ID {alert_id}?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )

        if reply == QMessageBox.Yes:
            if self.db_manager.delete_alert(alert_id):
                self.status_bar.showMessage(f"Alert ID {alert_id} deleted.", 3000)
                self.load_and_display_alerts()
                self.touch_alerts_flag_file()
            else:
                QMessageBox.critical(
                    self,
                    "Database Error",
                    f"Failed to delete alert ID {alert_id} from the database.",
                )

    def update_bulk_alert_options(self, index=None):
        """Updates conditions for bulk alerts based on selected metric."""
        metric_text = self.bulk_alert_metric_combo.currentText()
        self.bulk_alert_condition_combo.clear()
        if "%" in metric_text:
            self.bulk_alert_condition_combo.addItems(
                ["Increases by >", "Decreases by >"]
            )

    def handle_create_bulk_alerts(self):
        if not self.all_products_meta:
            QMessageBox.warning(
                self, "No Products", "No products available to apply bulk alerts to."
            )
            return

        metric_text = self.bulk_alert_metric_combo.currentText()
        condition_text = self.bulk_alert_condition_combo.currentText()

        try:
            threshold_percent = float(self.bulk_alert_threshold_input.text())
            if not (0 < threshold_percent <= 1000):
                QMessageBox.warning(
                    self,
                    "Input Error",
                    "Percentage threshold must be a positive number (e.g., 1 to 1000).",
                )
                return
        except ValueError:
            QMessageBox.warning(
                self, "Input Error", "Threshold percentage must be a valid number."
            )
            return

        comparison_period_hours = self.bulk_alert_comparison_period_spinbox.value()

        metric_db_val = (
            "price_change_percent"
            if "Price" in metric_text
            else "volume_change_percent"
        )
        condition_db_val = "increase" if "Increases" in condition_text else "decrease"

        bulk_quality = -1
        bulk_custom_message = None

        confirm_msg = (
            f"This will create a '{metric_text} {condition_text} {threshold_percent}% "
            f"(vs last {comparison_period_hours}h)' alert for ALL {len(self.all_products_meta)} tracked products "
            f"at 'Any Quality'.\n\nAre you sure you want to proceed?"
        )
        reply = QMessageBox.question(
            self,
            "Confirm Bulk Alert Creation",
            confirm_msg,
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )

        if reply == QMessageBox.No:
            return

        alerts_created_count = 0
        alerts_failed_count = 0
        for product in self.all_products_meta:
            product_db_id = product["id"]
            alert_id = self.db_manager.add_alert(
                product_db_id,
                bulk_quality,
                metric_db_val,
                condition_db_val,
                threshold_percent,
                comparison_period_hours,
                bulk_custom_message,
            )
            if alert_id:
                alerts_created_count += 1
            else:
                alerts_failed_count += 1
                print(
                    f"Failed to create bulk alert for product: {product['name']} (ID: {product_db_id})"
                )

        summary_message = (
            f"Bulk alert operation completed.\n"
            f"Alerts successfully created: {alerts_created_count}\n"
            f"Alerts failed (or already existed with exact params): {alerts_failed_count}"
        )
        QMessageBox.information(self, "Bulk Alert Status", summary_message)
        self.status_bar.showMessage(
            f"{alerts_created_count} bulk alerts created.", 5000
        )

        self.load_and_display_alerts()
        self.touch_alerts_flag_file()

    def load_and_display_alerts(self):
        self.alerts_table.setSortingEnabled(False)
        self.alerts_table.setRowCount(0)
        active_alerts = self.db_manager.get_active_alerts()

        if not active_alerts:
            self.alerts_table.setSortingEnabled(True)
            return

        for row_idx, alert_data in enumerate(active_alerts):
            self.alerts_table.insertRow(row_idx)

            q_display = (
                "Any" if alert_data["quality"] == -1 else str(alert_data["quality"])
            )
            metric_display = alert_data["metric"].replace("_", " ").title()
            condition_display = alert_data["condition"].title()
            threshold_display = str(alert_data["threshold_value"])
            if "percent" in alert_data["metric"]:
                threshold_display += "%"

            product_name_item = QTableWidgetItem(alert_data["product_name"])
            product_name_item.setData(Qt.UserRole, alert_data["id"])

            self.alerts_table.setItem(row_idx, 0, product_name_item)
            self.alerts_table.setItem(row_idx, 1, QTableWidgetItem(q_display))
            self.alerts_table.setItem(row_idx, 2, QTableWidgetItem(metric_display))
            self.alerts_table.setItem(row_idx, 3, QTableWidgetItem(condition_display))
            self.alerts_table.setItem(row_idx, 4, QTableWidgetItem(threshold_display))
            self.alerts_table.setItem(
                row_idx, 5, QTableWidgetItem(alert_data["custom_message"] or "")
            )

        self.alerts_table.setSortingEnabled(True)

    def populate_main_table(self):
        current_selection_data = None
        current_row_index = self.market_table.currentRow()
        if current_row_index >= 0 and current_row_index < self.market_table.rowCount():
            name_item = self.market_table.item(current_row_index, 0)
            if name_item:
                current_selection_data = name_item.data(Qt.UserRole)

        self.market_table.setSortingEnabled(False)
        self.market_table.setRowCount(0)
        latest_snapshots = self.db_manager.get_latest_market_snapshots()

        if not latest_snapshots:
            self.status_bar.showMessage("No market data in DB.", 5000)
            self.market_table.setSortingEnabled(True)
            self.clear_details_panel()
            return

        restored_selection_row = -1
        SHORT_TERM_PRICE_HOURS = 3

        def get_trend_string_and_icon(
            current_val,
            avg_val,
            data_points_for_avg,
            threshold_percent=20.0,
            is_price=False,
        ):
            icon = "–"
            color = Qt.gray
            percentage_str = "N/A"
            numeric_percentage = 0.0

            if current_val is None:
                icon = "❓"
                percentage_str = "Cur N/A"
            elif avg_val is not None and avg_val > 0:
                if current_val is not None:
                    percentage_change = ((current_val - avg_val) / avg_val) * 100
                    numeric_percentage = percentage_change
                    percentage_str = f"{percentage_change:+.1f}%"

                    effective_threshold_for_icon = threshold_percent
                    if is_price:
                        if threshold_percent > 2.0:
                            effective_threshold_for_icon = 1.0

                    if percentage_change < -effective_threshold_for_icon:
                        icon = "▼"
                        color = Qt.red
                    elif percentage_change > effective_threshold_for_icon:
                        icon = "▲"
                        color = Qt.darkGreen
                    else:
                        icon = "●"
                        color = Qt.yellow
                else:
                    icon = "❓"
                    percentage_str = "Cur N/A"
            elif (
                current_val is not None
                and current_val > 0
                and (avg_val is None or avg_val == 0)
                and data_points_for_avg > 0
            ):
                icon = "▲"
                color = Qt.darkGreen
                percentage_str = "New↑"
                numeric_percentage = float("inf")
            elif (
                current_val is not None
                and current_val == 0
                and avg_val is not None
                and avg_val > 0
            ):
                icon = "▼"
                color = Qt.red
                percentage_str = "Empty"
                numeric_percentage = float("-inf")

            return f"{icon} {percentage_str}", color, numeric_percentage

        def create_numeric_item(value, format_str="{:,.2f}"):
            item = QTableWidgetItem()
            if value is not None:
                try:
                    float_value = float(value)
                except (ValueError, TypeError):
                    item.setText(str(value))
                    item.setData(Qt.DisplayRole, str(value))
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    return item
                item.setData(Qt.DisplayRole, float_value)
                item.setText(
                    format_str.format(float_value) if format_str else str(float_value)
                )
            else:
                item.setText("N/A")
            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            return item

        for row_idx, snapshot in enumerate(latest_snapshots):
            self.market_table.insertRow(row_idx)

            product_db_id = snapshot["product_db_id"]
            product_name = snapshot["product_name"]
            resource_id = int(snapshot["resource_id"])
            quality = snapshot["quality"]
            current_lowest_price_val = snapshot["lowest_price"]
            qty_at_lowest = snapshot["total_quantity_at_lowest_price"]
            current_total_volume = snapshot["total_market_volume"]
            latest_timestamp_str = snapshot["timestamp"]

            stats_24h_price = self.db_manager.get_24_hour_average_price(
                product_db_id, quality
            )
            avg_price_24h = (
                stats_24h_price["avg_price_24h"]
                if stats_24h_price and stats_24h_price["avg_price_24h"] is not None
                else None
            )

            vol_stats_7d = self.db_manager.get_average_volume_for_period(
                product_db_id, quality, days=7
            )
            avg_vol_7d = (
                vol_stats_7d["avg_volume"]
                if vol_stats_7d and vol_stats_7d["avg_volume"] is not None
                else None
            )
            vol_dp_7d = vol_stats_7d["data_points"] if vol_stats_7d else 0
            vol_trend_display_7d, vol_color_7d, vol_numeric_7d = (
                get_trend_string_and_icon(
                    current_total_volume, avg_vol_7d, vol_dp_7d, 20.0, False
                )
            )

            vol_stats_3d = self.db_manager.get_average_volume_for_period(
                product_db_id, quality, days=3
            )
            avg_vol_3d = (
                vol_stats_3d["avg_volume"]
                if vol_stats_3d and vol_stats_3d["avg_volume"] is not None
                else None
            )
            vol_dp_3d = vol_stats_3d["data_points"] if vol_stats_3d else 0
            vol_trend_display_3d, vol_color_3d, vol_numeric_3d = (
                get_trend_string_and_icon(
                    current_total_volume, avg_vol_3d, vol_dp_3d, 15.0, False
                )
            )

            vol_stats_3h = self.db_manager.get_average_volume_for_period(
                product_db_id, quality, hours=3
            )
            avg_vol_3h = (
                vol_stats_3h["avg_volume"]
                if vol_stats_3h and vol_stats_3h["avg_volume"] is not None
                else None
            )
            vol_dp_3h = vol_stats_3h["data_points"] if vol_stats_3h else 0
            vol_trend_display_3h, vol_color_3h, vol_numeric_3h = (
                get_trend_string_and_icon(
                    current_total_volume, avg_vol_3h, vol_dp_3h, 10.0, False
                )
            )

            price_dp_24h = stats_24h_price["data_points_24h"] if stats_24h_price else 0
            price_trend_display_24h, price_color_24h, price_numeric_24h = (
                get_trend_string_and_icon(
                    current_lowest_price_val, avg_price_24h, price_dp_24h, 2.0, True
                )
            )

            price_3h_ago, _ = self.db_manager.get_price_at_time_ago(
                product_db_id, quality, hours_ago=SHORT_TERM_PRICE_HOURS
            )
            data_points_3h_price = 1 if price_3h_ago is not None else 0
            price_trend_display_3h, price_color_3h, price_numeric_3h = (
                get_trend_string_and_icon(
                    current_lowest_price_val,
                    price_3h_ago,
                    data_points_3h_price,
                    1.0,
                    True,
                )
            )

            name_item = QTableWidgetItem(str(product_name))
            self.check_and_set_icon(
                name_item, resource_id, for_table_type="Market Overview"
            )
            name_item.setData(
                Qt.UserRole,
                {
                    "db_id": product_db_id,
                    "quality": quality,
                    "resource_id": resource_id,
                    "name": product_name,
                    "latest_timestamp_utc": latest_timestamp_str,
                },
            )
            if (
                current_selection_data
                and current_selection_data["db_id"] == product_db_id
                and current_selection_data["quality"] == quality
            ):
                restored_selection_row = row_idx

            self.market_table.setItem(row_idx, 0, name_item)
            self.market_table.setItem(row_idx, 1, QTableWidgetItem(str(quality)))
            self.market_table.setItem(
                row_idx, 2, create_numeric_item(current_lowest_price_val, "${:,.2f}")
            )
            self.market_table.setItem(
                row_idx, 3, create_numeric_item(avg_price_24h, "${:,.2f}")
            )
            self.market_table.setItem(
                row_idx, 4, create_numeric_item(qty_at_lowest, "{:,.0f}")
            )
            self.market_table.setItem(
                row_idx, 5, create_numeric_item(current_total_volume, "{:,.0f}")
            )

            item_vol7d = QTableWidgetItem(vol_trend_display_7d)
            item_vol7d.setData(Qt.DisplayRole, vol_numeric_7d)
            item_vol7d.setForeground(QColor(vol_color_7d))
            item_vol7d.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.market_table.setItem(row_idx, 6, item_vol7d)

            item_vol3d = QTableWidgetItem(vol_trend_display_3d)
            item_vol3d.setData(Qt.DisplayRole, vol_numeric_3d)
            item_vol3d.setForeground(QColor(vol_color_3d))
            item_vol3d.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.market_table.setItem(row_idx, 7, item_vol3d)

            item_vol3h = QTableWidgetItem(vol_trend_display_3h)
            item_vol3h.setData(Qt.DisplayRole, vol_numeric_3h)
            item_vol3h.setForeground(QColor(vol_color_3h))
            item_vol3h.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.market_table.setItem(row_idx, 8, item_vol3h)

            item_price24h = QTableWidgetItem(price_trend_display_24h)
            item_price24h.setData(Qt.DisplayRole, price_numeric_24h)
            item_price24h.setForeground(QColor(price_color_24h))
            item_price24h.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.market_table.setItem(row_idx, 9, item_price24h)

            item_price3h = QTableWidgetItem(price_trend_display_3h)
            item_price3h.setData(Qt.DisplayRole, price_numeric_3h)
            item_price3h.setForeground(QColor(price_color_3h))
            item_price3h.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.market_table.setItem(row_idx, 10, item_price3h)

        self.market_table.setSortingEnabled(True)
        if self.filter_input.text():
            self.filter_table(self.filter_input.text())
        self.status_bar.showMessage(
            f"Market overview loaded: {len(latest_snapshots)} items.", 5000
        )

        if restored_selection_row != -1:
            self.market_table.selectRow(restored_selection_row)
            if not self.market_table.isRowHidden(restored_selection_row):
                self.on_table_item_clicked(
                    self.market_table.item(restored_selection_row, 0)
                )
            else:
                self.select_first_visible_or_clear()
        elif self.market_table.rowCount() > 0:
            self.select_first_visible_or_clear()
        else:
            self.clear_details_panel()

    def load_and_populate_warehouse(self):
        self.status_bar.showMessage(
            f"Loading warehouse data from {WAREHOUSE_FILE_PATH}...", 2000
        )
        raw_data_list = []
        try:
            with open(WAREHOUSE_FILE_PATH, "r", encoding="utf-8") as f:
                loaded_json = json.load(f)
            if isinstance(loaded_json, list):
                raw_data_list = loaded_json
            else:
                QMessageBox.warning(
                    self, "WH Data Error", f"WH JSON not list: '{WAREHOUSE_FILE_PATH}'"
                )
                self.status_bar.showMessage("Error: WH JSON not list.", 5000)
                self.warehouse_table.setRowCount(0)
                return
        except FileNotFoundError:
            QMessageBox.warning(
                self, "File Not Found", f"WH file not found: {WAREHOUSE_FILE_PATH}"
            )
            self.status_bar.showMessage(f"WH file not found.", 5000)
            self.warehouse_table.setRowCount(0)
            return
        except json.JSONDecodeError:
            QMessageBox.critical(
                self, "JSON Error", f"Error decoding WH JSON: {WAREHOUSE_FILE_PATH}"
            )
            self.status_bar.showMessage("Error decoding WH JSON.", 5000)
            self.warehouse_table.setRowCount(0)
            return
        except Exception as e:
            QMessageBox.critical(self, "Error Loading WH", f"Error: {e}")
            self.status_bar.showMessage(f"Error loading WH: {e}", 5000)
            self.warehouse_table.setRowCount(0)
            return
        self.warehouse_table.setSortingEnabled(False)
        self.warehouse_table.setRowCount(0)
        if not raw_data_list:
            self.status_bar.showMessage("Warehouse empty/no data.", 3000)
            self.warehouse_table.setSortingEnabled(True)
            self.warehouse_total_value_label.setText("Total WH Value: $0.00")
            self.warehouse_total_pl_label.setText("Total WH P/L: $0.00")
            return
        current_market_prices = {}
        latest_market_snapshots = self.db_manager.get_latest_market_snapshots()
        for snap in latest_market_snapshots:
            current_market_prices[(snap["product_db_id"], snap["quality"])] = snap[
                "lowest_price"
            ]
        overall_total_wh_value = 0.0
        overall_total_wh_pl = 0.0
        overall_total_acquisition_cost = 0.0
        processed_items_count = 0
        for item_data in raw_data_list:
            try:
                resource_id = int(item_data.get("kind", 0))
                quality = int(item_data.get("quality", 0))
                quantity = int(item_data.get("amount", 0))
                acquisition_cost_total = float(
                    item_data.get("cost", {}).get("market", 0.0)
                )
                acquisition_cost_per_unit = (
                    (acquisition_cost_total / quantity) if quantity > 0 else 0.0
                )
                product_meta_info = next(
                    (
                        p
                        for p in self.all_products_meta
                        if p["resource_id"] == resource_id
                    ),
                    None,
                )
                item_name = (
                    product_meta_info["name"]
                    if product_meta_info
                    else f"Unknown(ID:{resource_id})"
                )
                product_db_id = product_meta_info["id"] if product_meta_info else -1
            except (KeyError, ValueError, TypeError) as e:
                print(f"Skipping WH item: {item_data}, Error: {e}")
                continue
            current_market_price_unit = current_market_prices.get(
                (product_db_id, quality), 0.0
            )
            current_market_price_unit = (
                current_market_price_unit
                if current_market_price_unit is not None
                else 0.0
            )
            current_total_value = quantity * current_market_price_unit
            potential_pl = current_total_value - acquisition_cost_total
            pl_percentage = (
                ((potential_pl / acquisition_cost_total) * 100)
                if acquisition_cost_total > 0
                else 0.0
            )
            overall_total_wh_value += current_total_value
            overall_total_acquisition_cost += acquisition_cost_total
            self.warehouse_table.insertRow(processed_items_count)
            icon_item = QTableWidgetItem()
            self.check_and_set_icon(icon_item, resource_id, for_table_type="Warehouse")
            self.warehouse_table.setItem(processed_items_count, 0, icon_item)
            self.warehouse_table.setItem(
                processed_items_count, 1, QTableWidgetItem(item_name)
            )
            self.warehouse_table.setItem(
                processed_items_count, 2, QTableWidgetItem(str(quality))
            )
            qty_item = QTableWidgetItem()
            qty_item.setData(Qt.DisplayRole, quantity)
            self.warehouse_table.setItem(processed_items_count, 3, qty_item)
            acq_cost_item = QTableWidgetItem()
            acq_cost_item.setData(Qt.DisplayRole, acquisition_cost_total)
            acq_cost_item.setText(
                f"${acquisition_cost_total:,.2f}(${acquisition_cost_per_unit:,.2f}/u)"
            )
            self.warehouse_table.setItem(processed_items_count, 4, acq_cost_item)
            cur_price_item = QTableWidgetItem()
            cur_price_item.setData(Qt.DisplayRole, current_market_price_unit)
            cur_price_item.setText(f"${current_market_price_unit:,.2f}")
            self.warehouse_table.setItem(processed_items_count, 5, cur_price_item)
            cur_val_item = QTableWidgetItem()
            cur_val_item.setData(Qt.DisplayRole, current_total_value)
            cur_val_item.setText(f"${current_total_value:,.2f}")
            self.warehouse_table.setItem(processed_items_count, 6, cur_val_item)
            pl_item = QTableWidgetItem()
            pl_item.setData(Qt.DisplayRole, potential_pl)
            pl_item.setText(f"${potential_pl:,.2f}")
            if potential_pl > 0:
                pl_item.setForeground(Qt.darkGreen)
            elif potential_pl < 0:
                pl_item.setForeground(Qt.red)
            self.warehouse_table.setItem(processed_items_count, 7, pl_item)
            pl_perc_item = QTableWidgetItem()
            pl_perc_item.setData(Qt.DisplayRole, pl_percentage)
            pl_perc_item.setText(f"{pl_percentage:+.1f}%")
            if pl_percentage > 0:
                pl_perc_item.setForeground(Qt.darkGreen)
            elif pl_percentage < 0:
                pl_perc_item.setForeground(Qt.red)
            self.warehouse_table.setItem(processed_items_count, 8, pl_perc_item)
            processed_items_count += 1
        overall_total_wh_pl = overall_total_wh_value - overall_total_acquisition_cost
        self.warehouse_table.setSortingEnabled(True)
        self.warehouse_total_value_label.setText(
            f"Total WH Value: ${overall_total_wh_value:,.2f}"
        )
        pl_style = (
            "color:darkgreen;"
            if overall_total_wh_pl > 0
            else "color:red;" if overall_total_wh_pl < 0 else ""
        )
        self.warehouse_total_pl_label.setText(
            f"Total WH P/L: ${overall_total_wh_pl:,.2f}"
        )
        self.warehouse_total_pl_label.setStyleSheet(pl_style)
        self.status_bar.showMessage(
            f"Warehouse data processed: {processed_items_count} items.", 3000
        )

    def select_first_visible_or_clear(self):
        first_visible_row = -1
        for r in range(self.market_table.rowCount()):
            if not self.market_table.isRowHidden(r):
                first_visible_row = r
                break
        if first_visible_row != -1:
            self.market_table.selectRow(first_visible_row)
            self.on_table_item_clicked(self.market_table.item(first_visible_row, 0))
        else:
            self.clear_details_panel()

    def on_table_item_clicked(self, item):
        if not item:
            self.clear_details_panel()
            return
        row = item.row()
        if self.market_table.isRowHidden(row):
            return
        name_item_data = self.market_table.item(row, 0).data(Qt.UserRole)
        if not name_item_data:
            self.clear_details_panel()
            return
        product_db_id = name_item_data["db_id"]
        quality = name_item_data["quality"]
        product_name = name_item_data["name"]
        latest_timestamp_str = name_item_data.get("latest_timestamp_utc")
        current_lowest_str = self.market_table.item(row, 2).text()
        qty_at_lowest_str = self.market_table.item(row, 3).text()
        self.detail_product_name.setText(product_name)
        self.detail_quality.setText(str(quality))
        self.detail_current_lowest.setText(current_lowest_str)
        self.detail_qty_at_lowest.setText(qty_at_lowest_str)
        stats_7d = self.db_manager.get_7_day_stats(product_db_id, quality)
        avg_vol_7d_val = (
            stats_7d["avg_volume"]
            if stats_7d and stats_7d["avg_volume"] is not None
            else 0
        )
        avg_price_7d_val = (
            stats_7d["avg_price"]
            if stats_7d and stats_7d["avg_price"] is not None
            else 0
        )
        self.detail_avg_vol_7d.setText(f"{avg_vol_7d_val:.2f}")
        self.detail_avg_price_7d.setText(f"{avg_price_7d_val:.2f}")
        if latest_timestamp_str:
            try:
                dt_obj = datetime.fromisoformat(latest_timestamp_str)
                dt_display = (
                    dt_obj.astimezone(None).replace(tzinfo=None)
                    if dt_obj.tzinfo is not None
                    else dt_obj
                )
                self.detail_last_fetch_time.setText(
                    dt_display.strftime("%Y-%m-%d %H:%M:%S (Local)")
                )
            except ValueError:
                self.detail_last_fetch_time.setText(
                    f"Invalid date: {latest_timestamp_str}"
                )
        else:
            self.detail_last_fetch_time.setText("N/A")
        historical_data = self.db_manager.get_historical_data(
            product_db_id, quality, limit=self.plot_points_limit
        )
        ts = [r["timestamp"] for r in historical_data]
        pr = [r["lowest_price"] for r in historical_data]
        vols = [r["total_market_volume"] for r in historical_data]
        self.plot_canvas.plot_data(ts, pr, vols, product_name, quality)
        self.status_bar.showMessage(f"Details for {product_name} Q{quality}.", 3000)

    def clear_details_panel(self):
        self.detail_product_name.clear()
        self.detail_quality.clear()
        self.detail_current_lowest.clear()
        self.detail_qty_at_lowest.clear()
        self.detail_avg_vol_7d.clear()
        self.detail_avg_price_7d.clear()
        self.detail_last_fetch_time.clear()
        self.plot_canvas.plot_data([], [], [], "No Product Selected", "")
        self.status_bar.showMessage("No product selected.", 3000)

    def closeEvent(self, event):
        self.gui_refresh_timer.stop()
        print("Application closing.")
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_win = SimCompaniesHelperApp()
    main_win.show()
    sys.exit(app.exec_())
