import sqlite3
from datetime import datetime, timedelta, timezone

DB_NAME = "simcompanies_helper.db"


def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def initialize_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            resource_id INTEGER UNIQUE NOT NULL,
            realm_id INTEGER DEFAULT 0 NOT NULL
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS market_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            quality INTEGER NOT NULL,
            timestamp DATETIME NOT NULL,
            lowest_price REAL,
            total_quantity_at_lowest_price INTEGER,
            total_market_volume INTEGER,
            FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE, 
            /* Added ON DELETE CASCADE for products here too, good practice */
            UNIQUE (product_id, quality, timestamp)
        )
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_market_history_product_quality_timestamp
        ON market_history (product_id, quality, timestamp DESC)
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_db_id INTEGER NOT NULL,
            quality INTEGER NOT NULL,
            metric TEXT NOT NULL,              -- "price", "volume", "price_change_percent", "volume_change_percent"
            condition TEXT NOT NULL,           -- For absolute: "below", "above". For percent: "increase", "decrease" (or could be just "exceeds")
            threshold_value REAL NOT NULL,     -- Absolute value or percentage value
            comparison_period_hours INTEGER NULL, -- For percentage change alerts, e.g., 24, 72
            is_active BOOLEAN DEFAULT TRUE NOT NULL,
            last_triggered_at DATETIME NULL,
            custom_message TEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_db_id) REFERENCES products (id) ON DELETE CASCADE
        )
    """
    )

    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_alerts_product_metric_active
        ON alerts (product_db_id, quality, metric, is_active) -- Updated index name slightly
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS triggered_notifications_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_id INTEGER NOT NULL,             -- FK to alerts.id
            product_name TEXT NOT NULL,            -- Denormalized for easy display
            quality_display TEXT NOT NULL,         -- e.g., "Q0", "Any"
            message_title TEXT NOT NULL,
            message_body TEXT NOT NULL,
            triggered_at DATETIME NOT NULL,        -- When the service detected it
            is_acknowledged BOOLEAN DEFAULT FALSE NOT NULL,
            acknowledged_at DATETIME NULL,
            FOREIGN KEY (alert_id) REFERENCES alerts (id) ON DELETE SET NULL 
            -- ON DELETE SET NULL: if original alert definition is deleted, log entry remains but alert_id becomes NULL
            -- Alternatively, ON DELETE CASCADE if you want logs to disappear if the alert definition is removed.
            -- SET NULL is often better for logs to keep the record of what happened.
        )
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_triggered_notifications_log_acknowledged_time
        ON triggered_notifications_log (is_acknowledged, triggered_at DESC)
    """
    )

    conn.commit()
    conn.close()


def add_triggered_notification(
    alert_id, product_name, quality_display, title, body, triggered_at_dt
):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        print(
            f"DB_DEBUG: Attempting to log triggered notification: alert_id={alert_id}, product={product_name}, triggered_at={triggered_at_dt.isoformat()}"
        )
        cursor.execute(
            """
            INSERT INTO triggered_notifications_log 
                (alert_id, product_name, quality_display, message_title, message_body, triggered_at, is_acknowledged)
            VALUES (?, ?, ?, ?, ?, ?, FALSE)
        """,
            (alert_id, product_name, quality_display, title, body, triggered_at_dt),
        )
        conn.commit()
        log_id = cursor.lastrowid
        print(f"DB: Logged triggered notification ID {log_id} for alert ID {alert_id}")
        return log_id
    except sqlite3.Error as e:
        print(
            f"DB ERROR: Failed to log triggered notification for alert ID {alert_id}: {e}"
        )
        return None
    finally:
        conn.close()


def get_unacknowledged_notifications():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, alert_id, product_name, quality_display, message_title, message_body, triggered_at
        FROM triggered_notifications_log
        WHERE is_acknowledged = FALSE
        ORDER BY triggered_at DESC
    """
    )
    notifications = cursor.fetchall()
    conn.close()
    return notifications


def delete_acknowledged_notifications(older_than_days=None):
    """
    Deletes acknowledged notifications from 'triggered_notifications_log'.
    If older_than_days is specified (e.g., 7), only acknowledged notifications
    older than that many days will be deleted.
    If older_than_days is None, all acknowledged notifications are deleted.
    Returns True if successful, False otherwise.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        if older_than_days is not None and older_than_days > 0:
            cutoff_date = datetime.now() - timedelta(days=older_than_days)
            cursor.execute(
                """
                DELETE FROM triggered_notifications_log 
                WHERE is_acknowledged = TRUE AND triggered_at < ?
            """,
                (cutoff_date,),
            )
            action = f"older than {older_than_days} days"
        else:
            cursor.execute(
                "DELETE FROM triggered_notifications_log WHERE is_acknowledged = TRUE"
            )
            action = "all"

        conn.commit()
        deleted_count = cursor.rowcount
        print(f"DB: Deleted {deleted_count} acknowledged notifications ({action}).")
        return True
    except sqlite3.Error as e:
        print(f"DB ERROR: Failed to delete acknowledged notifications: {e}")
        return False
    finally:
        conn.close()


def get_all_notifications_sorted(limit=100):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, alert_id, product_name, quality_display, message_title, message_body, triggered_at, is_acknowledged, acknowledged_at
        FROM triggered_notifications_log
        ORDER BY triggered_at DESC
        LIMIT ?
    """,
        (limit,),
    )
    notifications = cursor.fetchall()
    conn.close()
    return notifications


def acknowledge_notification(notification_log_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        ack_time = datetime.now()
        cursor.execute(
            """
            UPDATE triggered_notifications_log 
            SET is_acknowledged = TRUE, acknowledged_at = ? 
            WHERE id = ? AND is_acknowledged = FALSE 
        """,
            (ack_time, notification_log_id),
        )
        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        print(
            f"DB ERROR: Failed to acknowledge notification log ID {notification_log_id}: {e}"
        )
        return False
    finally:
        conn.close()


def add_product_if_not_exists(name, resource_id, realm_id=0):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO products (name, resource_id, realm_id) VALUES (?, ?, ?)",
            (name, resource_id, realm_id),
        )
        conn.commit()
        print(f"Added product: {name}")
    except sqlite3.IntegrityError:
        print(f"Product {name} (ID: {resource_id}) already exists.")
        pass
    finally:
        conn.close()


def get_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, resource_id, realm_id FROM products ORDER BY name")
    products = cursor.fetchall()
    conn.close()
    return products


def add_market_data(
    product_db_id,
    quality,
    lowest_price,
    qty_at_lowest_price,
    total_volume,
    timestamp=None,
):
    conn = get_db_connection()
    cursor = conn.cursor()

    effective_timestamp = None
    if timestamp is None:
        effective_timestamp = datetime.now()
    else:
        if isinstance(timestamp, str):
            try:
                dt_obj = datetime.fromisoformat(timestamp)
                if dt_obj.tzinfo is not None:
                    effective_timestamp = dt_obj.astimezone(None).replace(tzinfo=None)
                else:
                    effective_timestamp = dt_obj
            except ValueError:
                print(
                    f"Warning: Could not parse provided timestamp string: {timestamp}. Using current local time."
                )
                effective_timestamp = datetime.now()
        elif isinstance(timestamp, datetime):
            if timestamp.tzinfo is not None:
                effective_timestamp = timestamp.astimezone(None).replace(tzinfo=None)
            else:
                effective_timestamp = timestamp
        else:
            print(
                f"Warning: Unknown timestamp type: {type(timestamp)}. Using current local time."
            )
            effective_timestamp = datetime.now()

    try:
        cursor.execute(
            """
            INSERT INTO market_history (product_id, quality, timestamp, lowest_price, total_quantity_at_lowest_price, total_market_volume)
            VALUES (?, ?, ?, ?, ?, ?)
        """,
            (
                product_db_id,
                quality,
                effective_timestamp,
                lowest_price,
                qty_at_lowest_price,
                total_volume,
            ),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        print(
            f"Data for product_id {product_db_id}, Q{quality} at {effective_timestamp.isoformat()} might already exist (UNIQUE constraint)."
        )
    finally:
        conn.close()


def get_historical_data(product_db_id, quality, limit=100):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT timestamp, lowest_price, total_market_volume
        FROM market_history
        WHERE product_id = ? AND quality = ?
        ORDER BY timestamp DESC
        LIMIT ?
    """,
        (product_db_id, quality, limit),
    )
    data = cursor.fetchall()
    conn.close()
    return data[::-1]


def get_latest_market_snapshots():
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
    SELECT
        p.id AS product_db_id,
        p.name AS product_name,
        p.resource_id,
        mh.quality,
        mh.timestamp,
        mh.lowest_price,
        mh.total_quantity_at_lowest_price,
        mh.total_market_volume
    FROM products p
    JOIN market_history mh ON p.id = mh.product_id
    WHERE mh.rowid IN (
        SELECT MAX(rowid)
        FROM market_history
        GROUP BY product_id, quality
    )
    ORDER BY p.name, mh.quality;
    """
    query_compatible = """
    SELECT
        p.id AS product_db_id,
        p.name AS product_name,
        p.resource_id,
        sub.quality,
        sub.timestamp,
        sub.lowest_price,
        sub.total_quantity_at_lowest_price,
        sub.total_market_volume
    FROM products p
    JOIN (
        SELECT 
            mh_inner.product_id,
            mh_inner.quality,
            mh_inner.timestamp,
            mh_inner.lowest_price,
            mh_inner.total_quantity_at_lowest_price,
            mh_inner.total_market_volume
        FROM market_history mh_inner
        INNER JOIN (
            SELECT product_id, quality, MAX(timestamp) as max_ts
            FROM market_history
            GROUP BY product_id, quality
        ) g ON mh_inner.product_id = g.product_id AND mh_inner.quality = g.quality AND mh_inner.timestamp = g.max_ts
    ) sub ON p.id = sub.product_id
    ORDER BY p.name, sub.quality;
    """
    cursor.execute(query_compatible)
    snapshots = cursor.fetchall()
    conn.close()
    return snapshots


def get_latest_price_for_product_quality(product_db_id, quality):
    """Gets the most recent lowest_price for a specific product_id and quality."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT lowest_price
        FROM market_history
        WHERE product_id = ? AND quality = ? AND lowest_price > 0
        ORDER BY timestamp DESC
        LIMIT 1
    """,
        (product_db_id, quality),
    )
    result = cursor.fetchone()
    conn.close()
    return result["lowest_price"] if result else None


def get_price_at_time_ago(product_db_id, quality, hours_ago=3):
    conn = get_db_connection()
    cursor = conn.cursor()
    target_time = datetime.now() - timedelta(hours=hours_ago)
    cursor.execute(
        """
        SELECT lowest_price, timestamp
        FROM market_history
        WHERE product_id = ? AND quality = ? AND timestamp <= ? AND lowest_price > 0
        ORDER BY timestamp DESC LIMIT 1 
    """,
        (product_db_id, quality, target_time),
    )
    result = cursor.fetchone()
    conn.close()
    return (result["lowest_price"], result["timestamp"]) if result else (None, None)


def get_7_day_stats(product_db_id, quality):
    conn = get_db_connection()
    cursor = conn.cursor()
    seven_days_ago = datetime.now() - timedelta(days=7)
    cursor.execute(
        """
        SELECT AVG(total_market_volume) as avg_volume, AVG(lowest_price) as avg_price, COUNT(*) as data_points
        FROM market_history WHERE product_id = ? AND quality = ? AND timestamp >= ?
    """,
        (product_db_id, quality, seven_days_ago),
    )
    stats = cursor.fetchone()
    conn.close()
    return stats


def get_24_hour_average_price(product_db_id, quality):
    conn = get_db_connection()
    cursor = conn.cursor()
    twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
    cursor.execute(
        """
        SELECT AVG(lowest_price) as avg_price_24h, COUNT(*) as data_points_24h
        FROM market_history WHERE product_id = ? AND quality = ? AND timestamp >= ? AND lowest_price > 0 
    """,
        (product_db_id, quality, twenty_four_hours_ago),
    )
    stats = cursor.fetchone()
    conn.close()
    return stats


def get_average_volume_for_period(product_db_id, quality, days=None, hours=None):
    """
    Calculates the average total_market_volume for a product/quality over a specified period.
    Specify either 'days' or 'hours'. If both, 'days' takes precedence.
    Returns a dictionary {'avg_volume': float, 'data_points': int} or None if no period given.
    """
    if not days and not hours:
        return {"avg_volume": None, "data_points": 0}

    conn = get_db_connection()
    cursor = conn.cursor()

    period_ago = None
    if days:
        period_ago = datetime.now() - timedelta(days=days)
    elif hours:
        period_ago = datetime.now() - timedelta(hours=hours)

    cursor.execute(
        """
        SELECT
            AVG(total_market_volume) as avg_volume,
            COUNT(*) as data_points
        FROM market_history
        WHERE product_id = ? AND quality = ? AND timestamp >= ? AND total_market_volume IS NOT NULL
    """,
        (product_db_id, quality, period_ago),
    )
    stats = cursor.fetchone()
    conn.close()

    if stats and stats["avg_volume"] is not None:
        return {
            "avg_volume": float(stats["avg_volume"]),
            "data_points": stats["data_points"],
        }
    elif stats:
        return {"avg_volume": None, "data_points": stats["data_points"]}
    return {"avg_volume": None, "data_points": 0}


def get_average_price_for_period(product_db_id, quality, days=None, hours=None):
    """
    Calculates the average lowest_price for a product/quality over a specified period.
    Specify either 'days' or 'hours'. If both, 'days' takes precedence.
    Returns a dictionary {'avg_price': float, 'data_points': int} or default if no period.
    """
    if not days and not hours:
        return {"avg_price": None, "data_points": 0}

    conn = get_db_connection()
    cursor = conn.cursor()

    if days:
        period_ago = datetime.now() - timedelta(days=days)
    elif hours:
        period_ago = datetime.now() - timedelta(hours=hours)
    else:
        conn.close()
        return {"avg_price": None, "data_points": 0}

    cursor.execute(
        """
        SELECT
            AVG(lowest_price) as avg_price,
            COUNT(*) as data_points
        FROM market_history
        WHERE product_id = ? AND quality = ? AND timestamp >= ? AND lowest_price > 0 
    """,
        (product_db_id, quality, period_ago),
    )
    stats = cursor.fetchone()
    conn.close()

    if stats and stats["avg_price"] is not None:
        return {
            "avg_price": float(stats["avg_price"]),
            "data_points": stats["data_points"],
        }
    elif stats:
        return {"avg_price": None, "data_points": stats["data_points"]}
    return {"avg_price": None, "data_points": 0}


def add_alert(
    product_db_id,
    quality,
    metric,
    condition,
    threshold_value,
    comparison_period_hours=None,
    custom_message=None,
):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            INSERT INTO alerts (product_db_id, quality, metric, condition, threshold_value, 
                                comparison_period_hours, custom_message, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, TRUE)
        """,
            (
                product_db_id,
                quality,
                metric,
                condition,
                threshold_value,
                comparison_period_hours,
                custom_message,
            ),
        )
        conn.commit()
        alert_id = cursor.lastrowid
        print(
            f"DB: Added alert ID {alert_id} for product {product_db_id}, Q{quality}, {metric} {condition} {threshold_value} (CompPeriod: {comparison_period_hours}h)"
        )
        return alert_id
    except sqlite3.Error as e:
        print(f"DB ERROR: Failed to add alert: {e}")
        return None
    finally:
        conn.close()


def get_active_alerts():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT 
            a.id, a.product_db_id, p.name as product_name, p.resource_id, 
            a.quality, a.metric, a.condition, a.threshold_value, a.comparison_period_hours,
            a.is_active, a.last_triggered_at, a.custom_message
        FROM alerts a
        JOIN products p ON a.product_db_id = p.id
        WHERE a.is_active = TRUE
    """
    )
    alerts = cursor.fetchall()
    conn.close()
    return alerts


def delete_alert(alert_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM alerts WHERE id = ?", (alert_id,))
        conn.commit()
        print(f"DB: Deleted alert ID {alert_id}")
        return True
    except sqlite3.Error as e:
        print(f"DB ERROR: Failed to delete alert ID {alert_id}: {e}")
        return False
    finally:
        conn.close()


def update_alert_last_triggered(alert_id, trigger_time):
    """Updates the last_triggered_at timestamp for an alert."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE alerts SET last_triggered_at = ? WHERE id = ?",
            (trigger_time, alert_id),
        )
        conn.commit()
        return True
    except sqlite3.Error as e:
        print(
            f"DB ERROR: Failed to update last_triggered_at for alert ID {alert_id}: {e}"
        )
        return False
    finally:
        conn.close()


def delete_product(product_db_id):
    """Deletes a product from the 'products' table."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM products WHERE id = ?", (product_db_id,))
        conn.commit()
        print(f"DB: Deleted product with db_id: {product_db_id} from 'products' table.")
        return True
    except sqlite3.Error as e:
        print(f"DB ERROR: Error deleting product {product_db_id} from 'products': {e}")
        return False
    finally:
        conn.close()


def delete_market_history_for_product(product_db_id):
    """Deletes all market history for a given product_db_id."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "DELETE FROM market_history WHERE product_id = ?", (product_db_id,)
        )
        conn.commit()
        print(f"DB: Deleted market history for product_db_id: {product_db_id}.")
        return True
    except sqlite3.Error as e:
        print(
            f"DB ERROR: Error deleting market history for product {product_db_id}: {e}"
        )
        return False
    finally:
        conn.close()


if __name__ == "__main__":
    initialize_db()
    print("Database initialized/updated with quality support.")
    products = get_products()
    print("Products in DB:")
    if products:
        for product_row in products:
            print(
                f"  ID: {product_row['id']}, Name: {product_row['name']}, Resource ID: {product_row['resource_id']}, Realm: {product_row['realm_id']}"
            )
    else:
        print("  No products found in the database.")
